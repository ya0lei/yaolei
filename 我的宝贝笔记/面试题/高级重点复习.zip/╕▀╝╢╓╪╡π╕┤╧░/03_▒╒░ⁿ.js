//什么是闭包?闭包的好处和坏处是什么?
//函数嵌套函数  里层的函数要访问外层函数的变量, 就产生闭包
//好处:延展了函数的作用域  
//坏处:容易造成内存溢出



// 下面有没有产生闭包呢?
// 没有闭包
function fn1() {
    let a = 1;
    return a
}
let res1 = fn1();
console.log(res1);



function fn2() {
    let a = 1;
    return function () {
        return a
    }
}
let res2 = fn2();

let bbb = res2()
console.log(bbb);
