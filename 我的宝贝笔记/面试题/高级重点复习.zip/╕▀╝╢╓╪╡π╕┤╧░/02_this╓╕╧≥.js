// this指向案例
// 1.普通函数
// let o = {
//     a: 1,
//     b: 2,
// }
// function fn1() {
//     console.log(this);
// }
let newFn = fn1.bind(o)
// newFn() // this指向o
// fn1()//
fn1.call(o, 1, 2) // 临时改变 this指向
fn1.apply(o, [1, 2]) // 临时改变  this指向
// //返回一个新函数, 这个新函数this已经被永久的改变了
// newFn() // this指向o
// fn1()//
// 2.对象中的函数

// o.fn(); //o

// // 3.定时器中
// setTimeout(function () {
//     console.log(this);
// }, 0) //window

// // 4.事件  伪代码
元素.onclick = function () {
    setTimeout(
        function () { console.log(this) }.bind(元素), 100)
}

// // 5. 构造函数中
// class Person {
//     constructor(name) {
//         this.name = name
//     }
//     play() {
//         console.log(this);
//     }
// }
// let p1 = new Person('张三'); //new关键字创建的对象  其实就是实例对象
// p1.play()

// //call()
// 函数名.call(this指向的对象)

// apply  bind


//总结: 谁调用指向谁(看函数前面谁.了他)   定时器内的指向window  构造函数的this指向实例对象