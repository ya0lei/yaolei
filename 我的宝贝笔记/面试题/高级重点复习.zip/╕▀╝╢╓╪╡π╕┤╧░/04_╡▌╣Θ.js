// 什么是递归?写递归需要什么注意事项?
// 自己调用自己, 一定要有结束条件, 否则会造成内存移除
// 深拷贝 方法 ①序列化(不是万能)  ②手动写深拷贝  利用递归遍历每一项

// 分析求阶乘 1*2*3*4*..n
function fn(n) {
    if (n == 1) {
        return 1
    }
    return n * fn(n - 1)
}
console.log(fn(4));


// 深拷贝 方法
let o1 = {
    a: 1,
    b: ['ha', 'he'],
    c: {
        age: 20
    }
}
//①序列化  如果对象里有函数, undefind, data对象都不行
// let o2 = JSON.parse(JSON.stringify(o1));

//②手动写深拷贝  利用递归遍历每一项
function deepClone(new_O, old_O) {
    for (let k in old_O) {
        // ①先判断是数组
        if (old_O[k] instanceof Array) {
            //1.1 创建一个空数组
            new_O[k] = [];
            //1.2 递归调用这个函数
            deepClone(new_O[k], old_O[k])
        } else if (old_O[k] instanceof Object) {
            // ②再判断是对象
            //1.1 创建一个空数组
            new_O[k] = {};
            //1.2 递归调用这个函数
            deepClone(new_O[k], old_O[k])
        } else {
            // 正常克隆
            new_O[k] = old_O[k]
        }
    }
    return new_O
}
let o2 = deepClone({}, o1)




// function fn() { } //字面量
// new Function() { } //创建函数的语法

// []
// new Array()
// new Object()
// console.log(Function.constructor);