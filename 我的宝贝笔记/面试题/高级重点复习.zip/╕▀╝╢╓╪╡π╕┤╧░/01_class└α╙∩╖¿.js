//面试题: 什么是class类?  super使用方式?

//1. 构造函数是什么?原型对象是什么?实例对象是什么?什么是构造器?静态成员是什么?
// ①构造函数用来创建对象
// ②原型对象   只要创建函数--->原型对象
// ③实例对象   new关键字调用函数 ---> 返回值 就叫实例对象
// ④构造器     保存在原型对象中, 用来指向构造函数(告诉别人我是谁的原型)
// ⑤静态成员   函数是复杂数据类型    function fn(){}    fn.a = 1

//2. 什么是class类?
//class类是ES6新增的   ES5构造函数的语法糖  

//3. 创建一个Person类, 需要传递2个参数name和age
class Person {
    constructor(name, age) {
        this.name = name;
        this.age = age
    }
    sing() {
        console.log(this.songs);
    }
}
let p1 = new Person('张三', 30)

//4. 给Person构造函数添加一个公共方法sing

//5. 给Person构造函数添加一个公共属性, songs, 保存的值是一个{0: '国歌', 1: '两只老虎', length: 2}
Person.prototype.songs = { 0: '国歌', 1: '两只老虎', length: 2 };

//6. 给Person构造函数添加一个静态成员sex, 值为'男'
Person.sex = '男'

//7. 修改sing函数内的代码, 改为log输出公共属性songs内保存的值
// p1.sing() //{0: '国歌', 1: '两只老虎', length: 2}

//8. 创建一个实例对象p1, 输出姓名,年龄,调用唱歌方法.
p1.name
p1.age

//9. 打印性别sex
// console.log(p1.constructor.sex);
// console.log(Person.sex);

//10. 创建一个学生类Student, 传递3个参数name,age,num学号, 添加一个公共方法do,代码是打印'写作业'
class Student extends Person {
    constructor(name, age, num) {
        super(name, age)
        this.num = num;
    }
    do() {
        //调用父类的sing方法
        // this.sing()
        super.sing() // 此时super就是父类的原型对象
    }
}
let stu = new Student('王五', 20, 1234)

//11. super关键字的作用?
//super有2个功能(必须要有继承)
//①当做函数使用  借用父类的构造器方法, 一定要写在constructor函数的第一行
//②当做对象使用  super如果当做一个对象来用, 那么他就代表的是父类的原型对象

//12. 学生类Student继承Person类. 他们的共有属性是name和age

//13. 创建学生对象, 访问私有属性name,age,num. 调用原型中的方法do. 调用继承父类方法sing, 打印继承父类songs属性
// stu.name
// stu.age
// stu.num
// stu.do()
// stu.sing() //this指向stu, 但是stu本身,原型都没有songs这个属性, 一直查到了父类原型内

//14. 修改do方法内容, 调用父类的公共方法sing
// stu.do()

//15. 通过Student函数访问父类Person中的静态成员sex
console.log(Student.sex); //现在自身构造函数查有没有这个静态成员,如果没有顺着一条线去查父类构造函数的静态成员


